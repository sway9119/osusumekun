require 'net/http'
require 'uri'
require 'json'
require 'nokogiri'
require 'open-uri'

def lambda_handler(event)
  
  books = get_amazon_sale_books
  
  # LINEへのPUSHメッセージ作成
  resmessage = [
    { 'type' => 'text', 'text' => "
    #{books[0][:title]}\n
    #{books[0][:price]}\n
    #{books[0][:link]}\n
    --------------------
    #{books[1][:title]}\n
    #{books[1][:price]}\n
    #{books[1][:link]}\n
    --------------------
    #{books[2][:title]}\n
    #{books[2][:price]}\n
    #{books[2][:link]}\n
    
    " },
  ]
  payload = { 'to' => 'Uf3d7887ab4b23eaa75d694794ea98461', 'messages' => resmessage }
  
  # カスタムヘッダーの生成(hash形式)
  headers = { 'Content-Type' => 'application/json', 'Authorization' => 'Bearer CGMT48p5yVSEsyDbj5RbGUClcJIDjui8dqixDYcZ1r4sG1TR8sq51thW3KgGeptJCVdzNTXDQ3ADqRQtPy1J53t2au2J65ZIWIBto5RCJpxEMx8TLJtNc4+PYqNymZ/jbijh2dHxaG9nVpuN03YpOAdB04t89/1O/w1cDnyilFU=' }

  # URIを作成
  uri = URI.parse('https://api.line.me/v2/bot/message/push')

  # HTTPリクエストを生成
  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.path, headers)
  request.body = JSON.generate(payload)

  # リクエストを送信
  response = http.request(request)

  puts 'LINEレスポンス:' + response.body
end

private

def get_amazon_sale_books
  # スクレイピング対象のURL
  url = 'https://yapi.ta2o.net/kndlsl/'

  # URLからHTMLを取得
  html = URI.open(url, 'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36').read
  # puts html
  # Nokogiriを使用してHTMLをパース
  doc = Nokogiri::HTML(html)

  # 日替わりセールの情報を取得
  books = doc.css('.book-list li')

  result = []

  books.each do |book|
    title = book.at('a').text.strip
    price = book.at('span').text.strip
    link = book.at('a')['href']
    result << {title: title, price: price, link: link}
  end
  return result
end